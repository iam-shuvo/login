<!DOCTYPE html>
<html>
<head>
  <title>Registration Form</title>
  <style>
    .ab{
  margin: auto;
  width: 30%;
  border: 2px solid green;
  padding: 10px;
  background-color: #2E86C1;
  text-align: center;
  margin-bottom: 10px;
}
.ac{
  margin: auto;
  width: 60%;
  border: 2px solid green;
  padding: 10px;
  background-color: #707B7C;
  text-align: center;
}
  </style>
</head>
<body>
  <div class="ab">
  <h1>Registration Form</h1>
  <form action="#" method="post">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" ><br><br>
  
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" ><br><br>
  
    <input type="submit" value="Submit" class="btn">
  </form>
  </div>
  <div class="ac">
  <?php
        include('displaydata.php');
  ?>
  <a href="index.php"><input type="button" value="logout"></a>
  </div>
</body>
</html>
