<?php include('database.php');
// $id = $_GET['id'];
// $sql = "SELECT * FROM datatable where id = $id ";
// $result = $conn->query($sql);
// $row = $result->fetch_assoc();
// ?>

// <form action="#" method="post">
//     <input type="hidden" name="id" value=" <?php  echo $row['id'];?>">
//       <label for="name">Name:</label>
//       <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>"><br><br>
    
//       <label for="email">Email:</label>
//       <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>"> <br><br>
    
//       <input type="submit" value="Delete">
//   </form>


// <?php
// if($_POST){
//   $id = $_POST['id'];
//   $name = $_POST['name'];
//   $email = $_POST['email'];
//   $sql = "DELETE FROM datatable WHERE id=$id";

//   if ($conn->query($sql) === TRUE) {
//     header("Location: form.php");
//   } else {
//     echo "Error updating record: " . $conn->error;
//   }
// }
?>