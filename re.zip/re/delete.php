<?php 
// include('updatedata.php');
    if (isset($_POST['delete'])){
        $sql = "DELETE FROM datatable WHERE id=$id";
        echo "$id";
        if ($conn->query($sql) === TRUE) {
          header("Location: form.php");
        } else {
          echo "Error updating record: " . $conn->error;
        }
      }
?>