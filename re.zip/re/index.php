<?php include('database.php')?>
<h1>login  </h1>
<form action="" method="post">
    <label for="">Email</label><br>
    <input type="email" name="email" id=""><br>
    <label for="password">Password</label><br>
    <input type="password" name="password" id=""><br>
    <input type="submit" value="login" name='sub'><br>
    <a href= "signup.php"> Create account </a>
</form>

<?php
if(isset($_POST['sub'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

if(!empty($email) && !empty($password)){
    $psw ="SELECT * FROM signup WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($psw);     
    if ($result->num_rows === 1) {
        header('location:form.php');
    } else {
        // Login failed
        echo "Invalid email or password. Please try again.";
    }
    }
}
?>