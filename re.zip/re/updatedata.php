<?php include('database.php');
$id = $_GET['id'];
$sql = "SELECT * FROM datatable where id = $id ";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<form action="#" method="post">
    <input type="hidden" name="id" value=" <?php  echo $row['id'];?>">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>"><br><br>
    
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>"> <br><br>
    
      <input type="submit" value="update" name="update">
      <input type="submit" value="delete" name="delete">
  </form>


<?php
include('delete.php');
// if (isset($_POST['delete'])){
//   $sql = "DELETE FROM datatable WHERE id=$id";
//   echo "$id";
//   if ($conn->query($sql) === TRUE) {
//     header("Location: form.php");
//   } else {
//     echo "Error updating record: " . $conn->error;
//   }
// }

if(isset($_POST['update'])){
  $id = $_POST['id'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  $sql = "UPDATE datatable SET name='$name' , email = '$email' WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    header("Location: form.php");
  } else {
    echo "Error updating record: " . $conn->error;
  }
}
?>