<?php include('database.php')?>
<h1>signup</h1>
<form action="" method="post">
    <label for="">Email</label><br>
    <input type="email" name="email" id=""><br>
    <label for="password">Password</label><br>
    <input type="password" name="password" id=""><br>
    <label for="password">Confrim Password</label><br>
    <input type="rpassword" name="rpassword" id=""><br>
    <input type="submit" value="signup" name='sub'><br>
    <a href="index.php">already have an account log in</a>
</form>

<?php 
if(isset($_POST['sub'])){
$email = $_POST['email'];
$password =($_POST['password']);

if(!empty($email) && !empty($password)){
    $sql = "INSERT INTO signup (email, password)
        VALUES ('$email','$password')";
        if ($conn->query($sql) === TRUE) {
            header("location:index.php");
        } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>