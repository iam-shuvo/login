<?php
    include("database.php");
    if($_POST){
        $name = $_POST['name'];
        $email = $_POST['email'];

    if(!empty($name) && !empty($email)){
        $sql = "INSERT INTO datatable (name, email)
            VALUES ('$name','$email')";

            if ($conn->query($sql) === TRUE) {
            } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
     }

?>