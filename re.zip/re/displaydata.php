<?php
include('userinput.php');
//view data
    $sql = "SELECT * FROM datatable"; 
    $result = $conn->query($sql);

    if($result->num_rows > 0) {
        echo "<table style='border: 1px solid black; background-color: #ABEBC6; width: 800px; text-align: center;'>";
        echo "<h3>User Information</h3>";
        echo "<tr style= 'padding: 20px; border: 1px solid black; background-color: #34495E; color: white;'><th>ID</th><th>Name</th> <th>Email</th> <th>Action</th> </tr>"; 
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td style= 'padding: 10px; border: 1px solid black; align:center'>" . $row["id"] . "</td>";
            echo "<td style= 'padding: 10px; border: 1px solid black;'>" . $row["name"] . "</td>";
            echo "<td style= 'padding: 10px; border: 1px solid black;'>" . $row["email"] . "</td>";
            echo "<td style= 'padding: 10px; border: 1px solid black;'>" . "<a href='updatedata.php?id=".$row['id']."'> <input type = 'submit' value='Data Update'></a>" . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }else{
        echo "No data found.";
    }
?>